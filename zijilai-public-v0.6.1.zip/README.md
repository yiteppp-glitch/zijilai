# ZIJILAI（自己来）— 给 Claude 装上眼睛和手

**专为 Claude 打造的浏览器侧边栏助手。** 原生 Claude（桌面端 / Claude Code）能通过 MCP 直接连浏览器干活；但通过 **API** 调用的 Claude 够不着你的浏览器——原生够不着，那就**自己来**。ZIJILAI 给它补上眼睛和手：用自然语言让它 **读网页、点击、填表、按键、滚动、截图、跳转、管理 / 整理标签页**，还能接入第三方 **MCP 工具**。OpenAI 兼容（Claude / GPT / Gemini 皆可），纯本地运行（除你配置的模型接口外无任何服务器）。

> 给别人用：发「公开版」zip，对方在设置里填自己的 Key 即可——密钥只存各自本地。

---

## 反过来：让原生 Claude（Claude Code / 桌面端）通过 MCP 驱动 ZIJILAI

侧边栏模式是「AI 跑在浏览器里」。如果你用的是**原生 Claude Code**，可以反过来——让它通过 MCP **把 ZIJILAI 当成自己的眼睛和手**：

```
Claude Code ──stdio/JSON-RPC──▶ bridge/bridge.js(零依赖纯 Node)
                                   │  WebSocket 127.0.0.1:2199
                                   ▼
                         ZIJILAI 后台 SW(wsbridge.js) ──runTool()──▶ 浏览器
```

**一键接入**——在解压后的扩展目录里跑：

```bash
node bridge/setup.mjs      # 或 bun bridge/setup.mjs
```

它会幂等地把 `zijilai` 写进 `~/.claude.json`（自动备份、不联网）。然后按提示：①`chrome://extensions` 加载/重载本扩展目录 ②重启 Claude Code。完成后即可调用 `mcp__zijilai__read_page / click / fill / screenshot / search_elements / computer …`。详见 [`bridge/README.md`](bridge/README.md)。

> `bridge/bridge.js` 零依赖、纯 Node 内置模块（Node≥18 或 Bun 均可，无需 npm install）。端口默认 `2199`，可用 `ZIJILAI_BRIDGE_PORT` 改。
> 安全：bridge 模式下动作由原生 Claude 直接调用（无侧边栏二次确认），由你在 Claude Code 侧把关。

---

## 安装
1. `chrome://extensions`（Edge：`edge://extensions`）→ 打开「开发者模式」
2. 「加载已解压的扩展程序」→ 选本文件夹
3. 点工具栏的 ZIJILAI 图标即可**打开侧边栏**；或按 `⌘⇧K` / `Ctrl+Shift+K`

## 配置（设置页）
- **自填接口**：填入你自己的 OpenAI 兼容 Base URL + Key + 模型即可使用（公开版未内置任何 Key，密钥只存你本地）。
- **自填接口**：用你自己的 OpenAI 兼容 Base URL + Key + 模型。
- **MCP 服务器**：可接入第三方**远程 MCP 服务器**（Streamable HTTP，https），让 AI 用上更多工具。设置页「MCP 服务器」里填名称 + URL（+ 可选 Bearer token / 自定义头），点「测试连接」看能拉到几个工具。例：`https://mcp.deepwiki.com/mcp`（免鉴权）。MCP 工具会以 `mcp__服务名__工具名` 的形式和内置工具一起给 AI 使用。
- 模型需支持**函数 / 工具调用**（多数现代多模态模型都支持）；想用截图视觉则还需支持图片输入。
- 可调：最大自动步数、温度、单步 tokens、是否允许截图、系统提示。

## 用法
打开侧边栏，直接说，或点顶部下方的**快捷指令**（总结本页 / 翻译本页 / 抓取链接 / 整理标签…）。例如：
- 「总结这个页面的要点」
- 「把搜索框填上 X 并搜索」
- 「找到登录按钮并点它」（敏感操作前它会先征求你确认）
- 「按主题把我打开的标签页分组整理」
- 「解释我选中的这段文字」 / 「在我的历史里找上周那篇文章」

AI 会逐步调用工具，侧边栏实时显示每一步。回复支持 **Markdown**，每条可**复制 / 重答**。点「停止」中断，「＋」开新对话，「☰」查看 / 切换 / 删除**历史会话**。

> 注意：侧边栏关闭会中断正在进行的任务和 MCP 连接（agent 跑在侧边栏页面里）。需要它干活时让侧边栏开着。

**右键菜单**：在任意网页右键 →「用 ZIJILAI 总结本页 / 处理选中文字 / 提取本页链接」，自动打开侧边栏并执行。

**快捷键**：`⌘⇧K` / `Ctrl+Shift+K` 打开侧边栏。

## 它能用的工具
read_page（可交互元素+uid）· find_elements · click · fill · press_key · scroll · extract_text · **get_selection（读选区）** · **get_links（抓链接）** · screenshot（视觉）· navigate · **go_back / go_forward / reload** · list_tabs · open_tab · switch_tab · close_tab · group_tabs（整理标签）· **search_history（搜历史）** · **search_bookmarks（搜书签）** · wait

## 安全
- 纯本地：对话、会话历史与设置只存浏览器；网页内容只发往你配置的模型接口。
- 新增的 `history` / `bookmarks` 权限仅在你明确要求「搜历史 / 搜书签」时被助手只读查询，不上传、不修改。
- **MCP 安全**：第三方 MCP 工具的名称/描述/返回内容都被当作**不可信外部数据**（系统提示已声明，不作为指令执行）；涉及**会改动页面/标签的内置动作**（跳转/填写/点击/开关标签等）会先弹**确认**，你点允许才执行。确认范围可在设置「敏感操作确认」里调整：关闭 / 仅启用 MCP 时（默认）/ 总是。MCP 返回的图片单独标注为外部数据、限量喂给视觉。
- 不可逆 / 敏感操作（下单、付款、删除、发消息、登录授权）前，助手会先停下来文字确认，不擅自执行。
- `chrome://`、应用商店等受限页面无法注入，会如实告知。
- 内置网关含预置 Key：私下用没问题；若要**公开分发**，请到设置改成「自填接口」或把 `src/defaults.js` 里的 PRESET.key 清空，避免密钥被滥用。

## 目录
```
manifest.json
background.js            侧边栏开关 / 快捷键
src/defaults.js          设置 + 双后端 + 系统提示
src/dom-agent.js         注入页面的 DOM 引擎（快照/点击/填写…）
src/tools.js             内置工具定义 + 执行器
src/mcp.js               远程 MCP 客户端（Streamable HTTP：握手/会话/SSE/tools 调用）
src/agent.js             工具调用循环（内置工具 + MCP 工具合并驱动）
sidepanel/               侧边栏聊天界面
options/                 设置页
icons/  ·  tools/gen-icons.mjs（bun 跑，生成图标）
```

v0.6.1 · Manifest V3 · 纯本地
