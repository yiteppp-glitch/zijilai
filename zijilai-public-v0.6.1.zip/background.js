// ZIJILAI — background service worker (MV3, module).
import { SETTINGS_KEY, DEFAULT_SETTINGS, PENDING_KEY } from './src/defaults.js';
import { startBridge } from './src/wsbridge.js';

// Connect to the local MCP bridge (zijilai-mcp-bridge) so an external Claude can drive the browser.
// Safe no-op if the bridge process isn't running — it just keeps retrying quietly.
const BRIDGE_ALARM = 'zijilai-bridge-keepalive';
startBridge();
try {
  chrome.alarms.create(BRIDGE_ALARM, { periodInMinutes: 0.4 });
  chrome.alarms.onAlarm.addListener((a) => { if (a.name === BRIDGE_ALARM) startBridge(); });
} catch (e) { console.warn('[ZIJILAI] alarms unavailable:', e?.message); }

async function enablePanelOnClick() {
  try {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
  } catch (e) {
    console.warn('[ZIJILAI] setPanelBehavior failed:', e?.message);
  }
}

function createMenus() {
  try {
    chrome.contextMenus.removeAll(() => {
      chrome.contextMenus.create({ id: 'aipex_summarize', title: '用 ZIJILAI 总结本页', contexts: ['page'] });
      chrome.contextMenus.create({ id: 'aipex_selection', title: '用 ZIJILAI 处理选中文字', contexts: ['selection'] });
      chrome.contextMenus.create({ id: 'aipex_links', title: '用 ZIJILAI 提取本页链接', contexts: ['page'] });
    });
  } catch (e) {
    console.warn('[ZIJILAI] createMenus failed:', e?.message);
  }
}

// Open the side panel SYNCHRONOUSLY inside a user-gesture callback.
// chrome.sidePanel.open() must be the first call — any await before it spends the gesture token.
function openPanelSync(tab) {
  const opt = tab?.id != null ? { tabId: tab.id } : (tab?.windowId != null ? { windowId: tab.windowId } : null);
  if (!opt) return;
  try { chrome.sidePanel.open(opt).catch((e) => console.warn('[ZIJILAI] open panel:', e?.message)); }
  catch (e) { console.warn('[ZIJILAI] open panel:', e?.message); }
}

chrome.runtime.onInstalled.addListener(async (details) => {
  const s = await chrome.storage.local.get(SETTINGS_KEY);
  if (!s[SETTINGS_KEY]) {
    await chrome.storage.local.set({ [SETTINGS_KEY]: DEFAULT_SETTINGS });
  }
  enablePanelOnClick();
  createMenus();
  if (details?.reason === 'install') {
    try { chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') }); } catch (e) {}
  }
});

chrome.runtime.onStartup?.addListener(() => { enablePanelOnClick(); createMenus(); });

// Right-click menu → open the panel FIRST (preserve user gesture), then stash the prompt.
chrome.contextMenus?.onClicked.addListener((info, tab) => {
  let text = '';
  if (info.menuItemId === 'aipex_summarize') text = '请总结当前这个网页的要点，分条列出。';
  else if (info.menuItemId === 'aipex_links') text = '提取当前页面上的主要链接（标题+网址），整理成列表。';
  else if (info.menuItemId === 'aipex_selection') {
    const sel = (info.selectionText || '').trim();
    text = '请处理我选中的这段文字（若我没进一步说明，就先解释并总结它）：\n\n"""\n' + sel + '\n"""';
  }
  if (!text) return;
  openPanelSync(tab); // must run before any await
  chrome.storage.local.set({ [PENDING_KEY]: { text, ts: Date.now() } }).catch(() => {}); // sidepanel consumes via storage.onChanged + init
});

// Keyboard shortcut → onCommand provides the active tab; open synchronously (no await before open).
chrome.commands?.onCommand.addListener((command, tab) => {
  if (command !== 'open-panel') return;
  openPanelSync(tab);
});
