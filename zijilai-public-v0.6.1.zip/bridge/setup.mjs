#!/usr/bin/env node
// ZIJILAI bridge 一键安装 — 让原生 Claude Code 通过 MCP 驱动 ZIJILAI 扩展。
// 用法：在解压后的扩展目录里跑   node bridge/setup.mjs   （或 bun bridge/setup.mjs）
// 它会幂等地把 zijilai 写进 ~/.claude.json 的 mcpServers，然后打印剩下两步。
// 零依赖、不联网、不改动扩展本身。

import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const bridgePath = path.join(__dirname, "bridge.js");          // <ext>/bridge/bridge.js
const extDir = path.dirname(__dirname);                         // <ext>/
const runtime = process.execPath;                              // 跑本脚本的 node/bun 绝对路径
const cfgPath = path.join(os.homedir(), ".claude.json");

const C = { g: "\x1b[32m", y: "\x1b[33m", b: "\x1b[1m", d: "\x1b[2m", r: "\x1b[0m", c: "\x1b[36m" };
const line = (s = "") => console.log(s);

line(`${C.b}ZIJILAI bridge 安装${C.r}`);
line(`${C.d}runtime: ${runtime}${C.r}`);
line(`${C.d}bridge : ${bridgePath}${C.r}`);

if (!fs.existsSync(bridgePath)) {
  line(`${C.y}✗ 找不到 ${bridgePath}${C.r} —— 请在解压后的扩展目录里运行本脚本。`);
  process.exit(1);
}

// 读取现有 ~/.claude.json（不存在则新建；解析失败则中止以免破坏）
let cfg = {};
if (fs.existsSync(cfgPath)) {
  const raw = fs.readFileSync(cfgPath, "utf8");
  try { cfg = JSON.parse(raw); }
  catch { line(`${C.y}✗ ${cfgPath} 不是合法 JSON，已中止（未改动你的文件）。请手动检查后重试。${C.r}`); process.exit(1); }
  fs.writeFileSync(cfgPath + ".bak-zijilai", raw);   // 备份
  line(`${C.d}已备份 -> ${cfgPath}.bak-zijilai${C.r}`);
}

if (!cfg.mcpServers || typeof cfg.mcpServers !== "object") cfg.mcpServers = {};
cfg.mcpServers.zijilai = { command: runtime, args: [bridgePath] };
fs.writeFileSync(cfgPath, JSON.stringify(cfg, null, 2));

line(`${C.g}✓ 已写入 ${cfgPath} 的 mcpServers.zijilai${C.r}`);
line("");
line(`${C.b}还差两步（手动）：${C.r}`);
line(`  ${C.c}1.${C.r} 打开 ${C.c}chrome://extensions${C.r} → 开启「开发者模式」→「加载已解压的扩展程序」选：`);
line(`     ${C.b}${extDir}${C.r}`);
line(`     （若已加载过，点该扩展的「🔄 重新加载」）`);
line(`  ${C.c}2.${C.r} ${C.b}重启 Claude Code${C.r}（退出再开），让它读到新的 mcpServers。`);
line("");
line(`完成后在 Claude Code 里说「用 zijilai 列出标签页」即可验证。`);
line(`${C.d}端口默认 2199，可设环境变量 ZIJILAI_BRIDGE_PORT 改。卸载：删掉 ~/.claude.json 里的 mcpServers.zijilai 即可。${C.r}`);
