# ZIJILAI bridge —— 让原生 Claude Code 通过 MCP 驱动浏览器（可选 / 高级）

> 普通用户不需要这个目录。装好扩展、在设置里填 Key、打开侧边栏就能用了。
> 这里只给 **Claude Code（原生客户端）** 用户：让 Claude 把 ZIJILAI 当成它自己的「眼睛和手」，直接读网页、点按、填表、截图、管标签。

## 一键接入
在**解压后的扩展目录**里运行（任选其一，有哪个用哪个）：

```bash
node bridge/setup.mjs      # 推荐，多数电脑自带 node
# 或
bun bridge/setup.mjs
```

它会把 `zijilai` 写进 `~/.claude.json` 的 `mcpServers`（幂等、自动备份、不联网）。然后按提示完成两步：

1. `chrome://extensions` → 开发者模式 →「加载已解压的扩展程序」选**本扩展目录**（已加载过就点「🔄 重新加载」）。
2. **重启 Claude Code**。

完成后在 Claude Code 里说「**用 zijilai 列出标签页**」即可验证，工具名为 `mcp__zijilai__*`（read_page / click / fill / screenshot / search_elements / computer …）。

## 说明
- `bridge.js`：**零依赖**，纯 Node.js 内置模块实现（`http`+`crypto` 手写 WebSocket 服务 + MCP-over-stdio）。Node ≥18 或 Bun 均可，**无需 npm install**。
- 端口默认 `2199`（与 AIPex 的 2192 不冲突）；可用环境变量 `ZIJILAI_BRIDGE_PORT` 修改。
- 让浏览器开着任意普通网页，以保持扩展后台存活。
- 安全：bridge 模式下动作由原生 Claude 直接调用（无侧边栏二次确认），信任模型与同类工具一致——由你在 Claude Code 侧把关。
- 卸载：删掉 `~/.claude.json` 里的 `mcpServers.zijilai` 即可。
