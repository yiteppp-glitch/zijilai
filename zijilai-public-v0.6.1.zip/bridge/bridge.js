#!/usr/bin/env node
// zijilai-mcp-bridge — connects Claude Code (or any MCP client) to the ZIJILAI browser extension.
// Topology:  MCP client <--stdio/JSON-RPC--> THIS PROCESS <--WebSocket(:2199)--> ZIJILAI extension --> browser
//
// ZERO dependencies. Runs on plain Node.js (>=18) AND Bun — uses only built-in node:http + node:crypto,
// with a hand-rolled RFC6455 WebSocket server and newline-delimited JSON-RPC 2.0 over stdio.
// (No bun, no ws, no @modelcontextprotocol/sdk required.)
// All logs MUST go to stderr — stdout is the MCP protocol channel.

import http from "node:http";
import crypto from "node:crypto";

const PORT = parseInt(process.env.ZIJILAI_BRIDGE_PORT || "2199", 10);
const HOST = "127.0.0.1";
const CALL_TIMEOUT = 60000;
const log = (...a) => console.error("[zijilai-bridge]", ...a);

// ---- Tool schemas (mirror of ZIJILAI src/tools.js). inputSchema === that tool's `parameters`. ----
const TOOLS = [
  { name: "read_page", description: "读取当前标签页：返回可交互元素列表（含 uid）、标题、页面文本大纲。点击/填写前应先调用它。", inputSchema: { type: "object", properties: {} } },
  { name: "find_elements", description: "按可见文字查找页面元素，返回匹配项及其 uid（read_page 太长时用）。", inputSchema: { type: "object", properties: { query: { type: "string", description: "要查找的文字" } }, required: ["query"] } },
  { name: "search_elements", description: "用 glob/grep 模式在当前页精准查找元素，返回匹配项及 uid（比 read_page 省 token）。支持 * ? [] {}，大小写不敏感。例：{button,link}* / *登录* / *Prada*June* / *[Ll]ogin*", inputSchema: { type: "object", properties: { query: { type: "string", description: "glob/grep 查询串" } }, required: ["query"] } },
  { name: "click", description: "点击 read_page/find_elements 返回的某个 uid 元素。", inputSchema: { type: "object", properties: { uid: { type: "string" } }, required: ["uid"] } },
  { name: "fill", description: "在某个输入框 uid 中填入文本。", inputSchema: { type: "object", properties: { uid: { type: "string" }, value: { type: "string" } }, required: ["uid", "value"] } },
  { name: "press_key", description: "在某个 uid（或当前焦点）上按键，常用 Enter 提交。", inputSchema: { type: "object", properties: { uid: { type: "string" }, key: { type: "string", description: "如 Enter" } }, required: ["key"] } },
  { name: "scroll", description: "滚动页面（up/down）或滚动到某个 uid。", inputSchema: { type: "object", properties: { direction: { type: "string", enum: ["up", "down"] }, uid: { type: "string" } } } },
  { name: "extract_text", description: "提取当前页面正文纯文本，用于总结/问答。", inputSchema: { type: "object", properties: {} } },
  { name: "get_selection", description: "读取用户在当前页面选中的文字。", inputSchema: { type: "object", properties: {} } },
  { name: "get_links", description: "提取当前页面上可见的链接（文字 + 网址）。", inputSchema: { type: "object", properties: {} } },
  { name: "screenshot", description: "截取当前可见页面（只能截前台可见的标签）。返回图像供你查看。", inputSchema: { type: "object", properties: {} } },
  { name: "navigate", description: "让当前标签页跳转到一个 URL。", inputSchema: { type: "object", properties: { url: { type: "string" } }, required: ["url"] } },
  { name: "go_back", description: "当前标签页后退一页。", inputSchema: { type: "object", properties: {} } },
  { name: "go_forward", description: "当前标签页前进一页。", inputSchema: { type: "object", properties: {} } },
  { name: "reload", description: "刷新当前标签页。", inputSchema: { type: "object", properties: {} } },
  { name: "search_history", description: "搜索用户的浏览历史。", inputSchema: { type: "object", properties: { query: { type: "string" }, max: { type: "number", description: "最多返回条数，默认 15" } }, required: ["query"] } },
  { name: "search_bookmarks", description: "搜索用户的书签。", inputSchema: { type: "object", properties: { query: { type: "string" } }, required: ["query"] } },
  { name: "list_tabs", description: "列出当前窗口所有标签页（带 #id、标题、URL；*为当前活动标签）。", inputSchema: { type: "object", properties: {} } },
  { name: "open_tab", description: "新开一个标签页打开 URL。", inputSchema: { type: "object", properties: { url: { type: "string" } }, required: ["url"] } },
  { name: "switch_tab", description: "切换到某个标签页（按 #id）。之后的页面操作都作用于它。", inputSchema: { type: "object", properties: { tabId: { type: "number" } }, required: ["tabId"] } },
  { name: "close_tab", description: "关闭某个标签页（按 #id）。", inputSchema: { type: "object", properties: { tabId: { type: "number" } }, required: ["tabId"] } },
  { name: "group_tabs", description: "把标签页按主题分组。groups 为 [{name, tabIds:[#id...]}]。", inputSchema: { type: "object", properties: { groups: { type: "array", items: { type: "object", properties: { name: { type: "string" }, tabIds: { type: "array", items: { type: "number" } } }, required: ["name", "tabIds"] } } }, required: ["groups"] } },
  { name: "computer", description: "坐标级输入兜底：uid 够不着时用（canvas、拖拽、滑块、悬浮菜单）。坐标是 screenshot 像素空间（自动按 devicePixelRatio 换算），需先 screenshot。", inputSchema: { type: "object", properties: { action: { type: "string", enum: ["left_click", "right_click", "double_click", "hover", "drag", "scroll", "type", "key"] }, x: { type: "number" }, y: { type: "number" }, x2: { type: "number" }, y2: { type: "number" }, dir: { type: "string", enum: ["up", "down", "left", "right"] }, text: { type: "string" }, key: { type: "string" } }, required: ["action"] } },
  { name: "get_editor_value", description: "读取代码编辑器（Monaco / CodeMirror）或 textarea 的完整内容（不被虚拟滚动截断）。", inputSchema: { type: "object", properties: {} } },
  { name: "upload_file_to_input", description: "把本地文件上传到页面 <input type=file>（chrome.debugger DOM.setFileInputFiles）。filePath 绝对路径；多个时用 inputIndex。", inputSchema: { type: "object", properties: { filePath: { type: "string" }, inputIndex: { type: "number" } }, required: ["filePath"] } },
  { name: "wait", description: "等待若干毫秒（页面加载/动画时用）。", inputSchema: { type: "object", properties: { ms: { type: "number" } }, required: ["ms"] } },
];

// ---- WebSocket hub (hand-rolled RFC6455) — the ZIJILAI extension connects here as a client. ----
const WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
let extSocket = null;        // raw net socket of the connected extension
let seq = 0;
const pending = new Map();   // id -> { resolve, reject, timer }

function sendFrame(socket, data, opcode = 0x1) {
  const payload = Buffer.isBuffer(data) ? data : Buffer.from(String(data), "utf8");
  const len = payload.length;
  let header;
  if (len < 126) {
    header = Buffer.from([0x80 | opcode, len]);
  } else if (len < 65536) {
    header = Buffer.allocUnsafe(4); header[0] = 0x80 | opcode; header[1] = 126; header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.allocUnsafe(10); header[0] = 0x80 | opcode; header[1] = 127;
    header.writeUInt32BE(Math.floor(len / 4294967296), 2); header.writeUInt32BE(len >>> 0, 6);
  }
  try { socket.write(Buffer.concat([header, payload])); } catch {}
}
function wsSend(obj) { if (extSocket) sendFrame(extSocket, JSON.stringify(obj), 0x1); }

function onWsMessage(text) {
  let m; try { m = JSON.parse(text); } catch { return; }
  if (m.type === "pong") return;
  if (m.type === "hello") { log("extension hello", m.version || ""); return; }
  if (m.type === "result") {
    const p = pending.get(m.id);
    if (!p) return;
    clearTimeout(p.timer); pending.delete(m.id);
    if (m.ok) p.resolve(m.result);
    else p.reject(new Error(m.error || "扩展执行失败"));
  }
}

function attachWs(socket) {
  extSocket = socket;
  log("extension connected");
  let buf = Buffer.alloc(0);
  let fragOpcode = 0, fragParts = [];
  socket.on("data", (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    while (true) {
      if (buf.length < 2) break;
      const b0 = buf[0], b1 = buf[1];
      const fin = (b0 & 0x80) !== 0;
      const opcode = b0 & 0x0f;
      const masked = (b1 & 0x80) !== 0;
      let len = b1 & 0x7f;
      let off = 2;
      if (len === 126) { if (buf.length < 4) break; len = buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (buf.length < 10) break; len = buf.readUInt32BE(2) * 4294967296 + buf.readUInt32BE(6); off = 10; }
      let mask = null;
      if (masked) { if (buf.length < off + 4) break; mask = buf.slice(off, off + 4); off += 4; }
      if (buf.length < off + len) break;            // frame incomplete — wait for more TCP data
      let payload = buf.slice(off, off + len);
      if (masked) { const o = Buffer.allocUnsafe(len); for (let i = 0; i < len; i++) o[i] = payload[i] ^ mask[i & 3]; payload = o; }
      buf = buf.slice(off + len);
      if (opcode === 0x8) { try { socket.end(); } catch {} return; }   // close
      if (opcode === 0x9) { sendFrame(socket, payload, 0xa); continue; } // ping -> pong
      if (opcode === 0xa) continue;                                     // pong
      if (opcode === 0x0) fragParts.push(payload);                      // continuation
      else { fragOpcode = opcode; fragParts = [payload]; }
      if (fin) {
        const full = Buffer.concat(fragParts); fragParts = [];
        if (fragOpcode === 0x1 || fragOpcode === 0x2) onWsMessage(full.toString("utf8"));
      }
    }
  });
  socket.on("close", () => { if (extSocket === socket) { extSocket = null; log("extension disconnected"); } });
  socket.on("error", () => { try { socket.destroy(); } catch {} });
}

function callExtension(tool, args) {
  return new Promise((resolve, reject) => {
    if (!extSocket) return reject(new Error("ZIJILAI 扩展未连接：请确认扩展已加载并启用（打开过一次浏览器/任意普通网页以唤醒后台）。"));
    const id = ++seq;
    const timer = setTimeout(() => { pending.delete(id); reject(new Error("调用超时（" + tool + "）")); }, CALL_TIMEOUT);
    pending.set(id, { resolve, reject, timer });
    try { wsSend({ type: "call", id, tool, args: args || {} }); }
    catch (e) { clearTimeout(timer); pending.delete(id); reject(e); }
  });
}

const server = http.createServer((req, res) => {
  if (req.url === "/health") { res.writeHead(200, { "content-type": "text/plain" }); res.end("ok"); return; }
  res.writeHead(200, { "content-type": "text/plain" }); res.end("zijilai-mcp-bridge");
});
server.on("upgrade", (req, socket) => {
  const key = req.headers["sec-websocket-key"];
  if (!key) { socket.destroy(); return; }
  const accept = crypto.createHash("sha1").update(key + WS_GUID).digest("base64");
  socket.write(
    "HTTP/1.1 101 Switching Protocols\r\n" +
    "Upgrade: websocket\r\n" +
    "Connection: Upgrade\r\n" +
    "Sec-WebSocket-Accept: " + accept + "\r\n\r\n"
  );
  socket.setNoDelay(true);
  attachWs(socket);
});
server.on("error", (e) => {
  // Port busy (stale bridge) or sandbox blocks listen — don't crash; keep MCP stdio alive so tools still list.
  log("WARN: 无法监听 " + HOST + ":" + PORT + "（" + (e && e.code) + "）。MCP stdio 仍在服务；端口空出前浏览器工具不可用。");
});
server.listen(PORT, HOST, () => log("WS hub listening on ws://" + HOST + ":" + PORT + "  (health: http://" + HOST + ":" + PORT + "/health)"));

// keepalive: app-level ping keeps the MV3 service worker (and its WS) alive
setInterval(() => { if (extSocket) wsSend({ type: "ping", id: ++seq }); }, 20000);

// ---- MCP over stdio (newline-delimited JSON-RPC 2.0) ----
function send(msg) { process.stdout.write(JSON.stringify(msg) + "\n"); }
function reply(id, result) { send({ jsonrpc: "2.0", id, result }); }
function replyErr(id, code, message) { send({ jsonrpc: "2.0", id, error: { code, message } }); }

async function handleCall(name, args) {
  if (!TOOLS.find((t) => t.name === name)) return { content: [{ type: "text", text: "未知工具：" + name }], isError: true };
  const res = await callExtension(name, args);   // { text, image? }
  const content = [];
  const text = (res && typeof res === "object") ? (res.text ?? "") : String(res ?? "");
  if (text) content.push({ type: "text", text });
  if (res && res.image && typeof res.image === "string") {
    const mm = res.image.match(/^data:(image\/[a-z]+);base64,(.*)$/i);
    if (mm) content.push({ type: "image", data: mm[2], mimeType: mm[1] });
  }
  if (!content.length) content.push({ type: "text", text: "(无返回)" });
  return { content };
}

async function dispatch(msg) {
  const { id, method, params } = msg;
  if (method === "initialize") {
    reply(id, { protocolVersion: params?.protocolVersion || "2025-06-18", capabilities: { tools: { listChanged: false } }, serverInfo: { name: "zijilai", version: "0.6.1" } });
    return;
  }
  if (method === "notifications/initialized" || method === "initialized") return;
  if (method === "ping") { reply(id, {}); return; }
  if (method === "tools/list") { reply(id, { tools: TOOLS }); return; }
  if (method === "tools/call") {
    try { reply(id, await handleCall(params?.name, params?.arguments || {})); }
    catch (e) { reply(id, { content: [{ type: "text", text: "工具执行出错：" + (e?.message || String(e)) }], isError: true }); }
    return;
  }
  if (id !== undefined) replyErr(id, -32601, "Method not found: " + method);
}

let stdinBuf = "";
process.stdin.on("data", (chunk) => {
  stdinBuf += chunk.toString("utf8");
  let i;
  while ((i = stdinBuf.indexOf("\n")) >= 0) {
    const line = stdinBuf.slice(0, i).trim();
    stdinBuf = stdinBuf.slice(i + 1);
    if (!line) continue;
    let msg; try { msg = JSON.parse(line); } catch { continue; }
    dispatch(msg).catch((e) => log("dispatch error", e?.message || e));
  }
});
process.stdin.on("end", () => process.exit(0));
process.stdin.resume();
