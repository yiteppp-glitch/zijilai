import { getSettings, saveSettings, resolveBackend, MODEL_PRESETS, DEFAULT_SETTINGS } from '../src/defaults.js';
import { connect, listTools, disconnect } from '../src/mcp.js';

const $ = (id) => document.getElementById(id);
const TEXT = ['customUrl', 'customKey', 'customModel', 'systemPrompt'];
const NUM = ['temperature', 'maxTokens', 'maxSteps'];
let mcpList = [];   // in-memory copy of settings.mcpServers

const modelSel = $('presetModel');
MODEL_PRESETS.forEach((m) => { const o = document.createElement('option'); o.value = m; o.textContent = m; modelSel.appendChild(o); });

function provider() { return document.querySelector('input[name=provider]:checked')?.value || 'preset'; }
function toggleBoxes() {
  const p = provider();
  $('presetBox').hidden = p !== 'preset';
  $('customBox').hidden = p !== 'custom';
}

function readForm() {
  const s = { provider: provider(), presetModel: modelSel.value, useVision: $('useVision').checked, confirmMode: $('confirmMode').value, mcpServers: mcpList.map((m) => { const c = { ...m }; delete c._headersRaw; return c; }) };
  TEXT.forEach((k) => { s[k] = $(k).value; });
  NUM.forEach((k) => { s[k] = Number($(k).value); });
  return s;
}
function fillForm(s) {
  document.querySelectorAll('input[name=provider]').forEach((r) => { r.checked = r.value === (s.provider || 'preset'); });
  modelSel.value = s.presetModel || MODEL_PRESETS[0];
  TEXT.forEach((k) => { $(k).value = s[k] ?? ''; });
  NUM.forEach((k) => { $(k).value = s[k]; });
  $('useVision').checked = !!s.useVision;
  $('confirmMode').value = s.confirmMode || 'mcp';
  mcpList = (s.mcpServers || []).map((x) => ({ ...x, enabled: x.enabled !== false }));
  renderMcp();
  toggleBoxes();
}

let timer = null;
function scheduleSave() {
  clearTimeout(timer);
  const hint = $('saveHint'); hint.textContent = '保存中…'; hint.className = 'savehint';
  timer = setTimeout(async () => { await saveSettings(readForm()); hint.textContent = '✓ 已保存到本地'; hint.className = 'savehint saved'; }, 400);
}

(async () => { fillForm(await getSettings()); })();

document.querySelectorAll('input, select, textarea').forEach((elm) => {
  elm.addEventListener('input', scheduleSave);
  elm.addEventListener('change', scheduleSave);
});
document.querySelectorAll('input[name=provider]').forEach((r) => r.addEventListener('change', toggleBoxes));
$('togKey').addEventListener('click', () => {
  const k = $('customKey'); const show = k.type === 'password';
  k.type = show ? 'text' : 'password'; $('togKey').textContent = show ? '隐藏' : '显示';
});
$('resetSys').addEventListener('click', () => { $('systemPrompt').value = DEFAULT_SETTINGS.systemPrompt; scheduleSave(); });
$('save').addEventListener('click', async () => { clearTimeout(timer); await saveSettings(readForm()); const h = $('saveHint'); h.textContent = '✓ 已保存到本地'; h.className = 'savehint saved'; });

$('test').addEventListener('click', async () => {
  const st = $('testStatus'); st.className = 'teststatus run'; st.textContent = '正在测试…';
  const be = resolveBackend(readForm());
  if (!be.apiKey) { st.className = 'teststatus bad'; st.textContent = '✗ 没有可用 Key（选内置网关或填 Key）'; return; }
  const endpoint = be.baseUrl.replace(/\/+$/, '') + '/chat/completions';
  const opts = { omitTemp: false, mtParam: 'max_tokens' };
  const build = () => { const b = { model: be.model, messages: [{ role: 'user', content: 'reply with: ok' }] }; if (!opts.omitTemp) b.temperature = 0.2; b[opts.mtParam] = 16; return b; };
  const post = (b) => fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + be.apiKey }, body: JSON.stringify(b) });
  try {
    let res = await post(build());
    for (let i = 0; i < 3 && !res.ok && (res.status === 400 || res.status === 422); i++) {
      const peek = (await res.clone().text().catch(() => '')).toLowerCase(); let ch = false;
      if (!opts.omitTemp && /temperature/.test(peek)) { opts.omitTemp = true; ch = true; }
      if (opts.mtParam === 'max_tokens' && /max_completion_tokens/.test(peek)) { opts.mtParam = 'max_completion_tokens'; ch = true; }
      if (!ch) break; res = await post(build());
    }
    if (!res.ok) { const d = await res.text().catch(() => ''); throw new Error(res.status + '：' + d.slice(0, 160)); }
    const data = await res.json().catch(() => ({}));
    if (data?.error) throw new Error(String(data.error.message || data.error).slice(0, 160));
    if (!data?.choices?.[0]) throw new Error('返回无 choices');
    st.className = 'teststatus ok'; st.textContent = '✓ 连接成功（' + be.model + '）';
  } catch (e) { st.className = 'teststatus bad'; st.textContent = '✗ ' + (e.message || '失败'); }
});

// ---------- MCP servers ----------
function uuid() { try { return crypto.randomUUID(); } catch { return 's' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); } }
function elc(tag, cls) { const n = document.createElement(tag); if (cls) n.className = cls; return n; }

function renderMcp() {
  const wrap = $('mcpList');
  wrap.innerHTML = '';
  if (!mcpList.length) {
    const empty = elc('p', 'desc');
    empty.textContent = '还没有 MCP 服务器。点下面按钮添加，例如 https://mcp.deepwiki.com/mcp（免鉴权，可直接测试）。';
    wrap.appendChild(empty);
    return;
  }
  mcpList.forEach((srv, i) => wrap.appendChild(rowFor(srv, i)));
}

function rowFor(srv, i) {
  const row = elc('div', 'mcp-row');

  const top = elc('div', 'mcp-top');
  const name = elc('input', 'mcp-name'); name.type = 'text'; name.placeholder = '名称（如 deepwiki）'; name.value = srv.name || '';
  const url = elc('input', 'mcp-url'); url.type = 'text'; url.placeholder = 'https://mcp.deepwiki.com/mcp'; url.spellcheck = false; url.value = srv.url || '';
  top.append(name, url);

  const grid = elc('div', 'mcp-grid');
  const token = elc('input', 'mcp-token'); token.type = 'password'; token.placeholder = 'Bearer token（可空）'; token.autocomplete = 'off'; token.value = srv.token || '';
  const headers = elc('textarea', 'mcp-headers'); headers.placeholder = '自定义头 JSON，如 {"X-API-Key":"..."}（可空）'; headers.spellcheck = false;
  headers.value = srv._headersRaw != null ? srv._headersRaw : (srv.headers && Object.keys(srv.headers).length ? JSON.stringify(srv.headers) : '');
  grid.append(token, headers);

  const bottom = elc('div', 'mcp-bottom');
  const tog = elc('label', 'mcp-toggle');
  const chk = elc('input'); chk.type = 'checkbox'; chk.checked = srv.enabled !== false;
  tog.append(chk, document.createTextNode('启用'));
  const testBtn = elc('button', 'mcp-test ghost small'); testBtn.type = 'button'; testBtn.textContent = '测试连接';
  const delBtn = elc('button', 'mcp-del'); delBtn.type = 'button'; delBtn.textContent = '删除';
  const status = elc('span', 'mcp-teststatus');
  bottom.append(tog, testBtn, delBtn, status);

  row.append(top, grid, bottom);

  // sync inputs back into the model; returns false if headers JSON is invalid
  const sync = () => {
    srv.name = name.value.trim();
    srv.url = url.value.trim();
    srv.token = token.value;
    srv.enabled = chk.checked;
    srv._headersRaw = headers.value; // preserve raw text across re-render (even when invalid)
    const ht = headers.value.trim();
    const clearMsg = () => { if (/JSON|覆盖/.test(status.textContent)) { status.textContent = ''; status.className = 'mcp-teststatus'; } };
    if (!ht) { srv.headers = {}; clearMsg(); return true; }
    try {
      const o = JSON.parse(ht);
      if (!o || typeof o !== 'object' || Array.isArray(o)) throw 0;
      srv.headers = o;
      const hasAuth = Object.keys(o).some((k) => k.toLowerCase() === 'authorization');
      if (hasAuth && srv.token) { status.className = 'mcp-teststatus run'; status.textContent = '注意：自定义头里的 Authorization 会覆盖上面的 token'; }
      else clearMsg();
      return true;
    } catch {
      status.className = 'mcp-teststatus bad'; status.textContent = '✗ 自定义头不是合法 JSON 对象';
      return false;
    }
  };

  [name, url, token].forEach((e) => e.addEventListener('input', () => { sync(); scheduleSave(); }));
  headers.addEventListener('input', () => { sync(); scheduleSave(); });
  chk.addEventListener('change', () => { sync(); scheduleSave(); });
  delBtn.addEventListener('click', () => { mcpList.splice(i, 1); renderMcp(); scheduleSave(); });
  testBtn.addEventListener('click', async () => { if (sync()) await testMcpRow(srv, status); });

  return row;
}

async function testMcpRow(server, status) {
  if (!/^https:\/\//i.test(server.url || '')) { status.className = 'mcp-teststatus bad'; status.textContent = '✗ url 必须是 https://'; return; }
  status.className = 'mcp-teststatus run'; status.textContent = '测试中…';
  let client = null;
  try {
    client = await connect(server, { timeout: 12000 });
    const tools = await listTools(client);
    status.className = 'mcp-teststatus ok';
    status.textContent = '✓ 连接成功（' + (client.serverInfo?.name || '服务器') + ' / 协议 ' + client.protocolVersion + ' / ' + tools.length + ' 个工具）';
  } catch (e) {
    status.className = 'mcp-teststatus bad';
    status.textContent = '✗ ' + String(e?.message || e).slice(0, 160);
  } finally {
    if (client) disconnect(client);
  }
}

$('mcpAdd').addEventListener('click', () => {
  mcpList.push({ id: uuid(), name: '', url: '', token: '', headers: {}, enabled: true });
  renderMcp();
  scheduleSave();
});
