// ZIJILAI — browser tools. Runs in the side-panel context (chrome.* available).
// DOM actions go through the injected dom-agent; tabs/screenshot/navigate use chrome APIs.

async function activeTab() {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!t) throw new Error('找不到活动标签页');
  return t;
}

// Pages where content scripts can't be injected (URL-based, independent of locale error text).
const RESTRICTED_URL = /^(chrome|chrome-extension|edge|about|view-source|devtools|moz-extension):|^https:\/\/chromewebstore\.google\.com|^https:\/\/chrome\.google\.com\/webstore/i;

async function ensureDom(tabId) {
  let url = '';
  try { url = (await chrome.tabs.get(tabId))?.url || ''; } catch {}
  if (RESTRICTED_URL.test(url)) throw new Error('该页面受限，无法读取或操作（' + (url.split('/').slice(0, 1)[0] || '受限页') + '）。请切换到一个普通网页再试。');
  await chrome.scripting.executeScript({ target: { tabId }, files: ['src/dom-agent.js'] });
}

async function domCmd(tabId, msg) {
  const payload = { __aipex: true, ...msg };
  try {
    return await chrome.tabs.sendMessage(tabId, payload);
  } catch {
    await ensureDom(tabId);
    return await chrome.tabs.sendMessage(tabId, payload);
  }
}

function waitForLoad(tabId, timeout = 15000) {
  return new Promise((resolve) => {
    const t0 = Date.now();
    const iv = setInterval(async () => {
      try {
        const tb = await chrome.tabs.get(tabId);
        if (tb.status === 'complete' || Date.now() - t0 > timeout) { clearInterval(iv); resolve(tb); }
      } catch { clearInterval(iv); resolve(null); }
    }, 300);
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, Math.min(ms || 0, 8000)));
const tabLine = (t) => `#${t.id}${t.active ? '*' : ''} ${(t.title || '').slice(0, 60)} — ${t.url || ''}`;

// Runs in the page's MAIN world (injected on demand) to read full editor content that
// isolated content scripts can't reach (Monaco/CodeMirror live on page globals).
function __zijilaiReadEditor() {
  try {
    if (window.monaco && window.monaco.editor) {
      const eds = window.monaco.editor.getEditors ? window.monaco.editor.getEditors() : [];
      if (eds && eds.length) {
        const ed = eds.find((e) => e.hasTextFocus && e.hasTextFocus()) || eds[0];
        const v = ed.getModel && ed.getModel() && ed.getModel().getValue();
        if (v != null) return v;
      }
      const models = window.monaco.editor.getModels ? window.monaco.editor.getModels() : [];
      if (models && models.length) return models.map((m) => m.getValue()).join('\n\n/* — next model — */\n\n');
    }
  } catch (e) {}
  try { const cm5 = document.querySelector('.CodeMirror'); if (cm5 && cm5.CodeMirror) return cm5.CodeMirror.getValue(); } catch (e) {}
  try {
    const cm6 = document.querySelector('.cm-editor');
    if (cm6) {
      const content = cm6.querySelector('.cm-content');
      const view = (cm6.cmView && cm6.cmView.view) || (content && content.cmView && content.cmView.view);
      if (view) return view.state.doc.toString();
    }
  } catch (e) {}
  try {
    const ae = document.activeElement;
    if (ae && (ae.tagName === 'TEXTAREA' || ae.tagName === 'INPUT')) return ae.value;
    const ta = document.querySelector('textarea'); if (ta) return ta.value;
  } catch (e) {}
  return '';
}

function sendDbg(tabId, method, params) { return chrome.debugger.sendCommand({ tabId }, method, params || {}); }

// name -> { schema, run(args) -> string | {__image} }
export const TOOLS = {
  read_page: {
    schema: { name: 'read_page', description: '读取当前标签页：返回可交互元素列表（含 uid）、标题、页面文本大纲。点击/填写前应先调用它。', parameters: { type: 'object', properties: {} } },
    run: async () => {
      const t = await activeTab();
      await ensureDom(t.id);
      const r = await domCmd(t.id, { cmd: 'snapshot' });
      return r?.ok ? r.data : '读取失败：' + (r?.error || '未知');
    }
  },
  find_elements: {
    schema: { name: 'find_elements', description: '按可见文字查找页面元素，返回匹配项及其 uid（read_page 太长时用）。', parameters: { type: 'object', properties: { query: { type: 'string', description: '要查找的文字' } }, required: ['query'] } },
    run: async ({ query }) => {
      const t = await activeTab(); await ensureDom(t.id);
      const r = await domCmd(t.id, { cmd: 'find', query });
      return r?.ok ? r.data : '查找失败：' + (r?.error || '');
    }
  },
  search_elements: {
    schema: { name: 'search_elements', description: '用 glob/grep 模式在当前页精准查找元素，返回匹配项及 uid（比 read_page 省 token）。支持 * ? [] {}，大小写不敏感。例：{button,link}* / *登录* / *Prada*June* / *[Ll]ogin*', parameters: { type: 'object', properties: { query: { type: 'string', description: 'glob/grep 查询串' } }, required: ['query'] } },
    run: async ({ query }) => {
      const t = await activeTab(); await ensureDom(t.id);
      const r = await domCmd(t.id, { cmd: 'search', query });
      return r?.ok ? r.data : '搜索失败：' + (r?.error || '');
    }
  },
  click: {
    schema: { name: 'click', description: '点击 read_page/find_elements 返回的某个 uid 元素。', parameters: { type: 'object', properties: { uid: { type: 'string' } }, required: ['uid'] } },
    run: async ({ uid }) => {
      const t = await activeTab();
      const r = await domCmd(t.id, { cmd: 'click', uid });
      return r?.ok ? r.data : '点击失败：' + (r?.error || '');
    }
  },
  fill: {
    schema: { name: 'fill', description: '在某个输入框 uid 中填入文本。', parameters: { type: 'object', properties: { uid: { type: 'string' }, value: { type: 'string' } }, required: ['uid', 'value'] } },
    run: async ({ uid, value }) => {
      const t = await activeTab();
      const r = await domCmd(t.id, { cmd: 'fill', uid, value });
      return r?.ok ? r.data : '填写失败：' + (r?.error || '');
    }
  },
  press_key: {
    schema: { name: 'press_key', description: '在某个 uid（或当前焦点）上按键，常用 Enter 提交。', parameters: { type: 'object', properties: { uid: { type: 'string' }, key: { type: 'string', description: '如 Enter' } }, required: ['key'] } },
    run: async ({ uid, key }) => {
      const t = await activeTab();
      const r = await domCmd(t.id, { cmd: 'key', uid, key });
      return r?.ok ? r.data : '按键失败：' + (r?.error || '');
    }
  },
  scroll: {
    schema: { name: 'scroll', description: '滚动页面（up/down）或滚动到某个 uid。', parameters: { type: 'object', properties: { direction: { type: 'string', enum: ['up', 'down'] }, uid: { type: 'string' } } } },
    run: async ({ direction, uid }) => {
      const t = await activeTab();
      const r = await domCmd(t.id, { cmd: 'scroll', direction, uid });
      return r?.ok ? r.data : '滚动失败：' + (r?.error || '');
    }
  },
  extract_text: {
    schema: { name: 'extract_text', description: '提取当前页面正文纯文本，用于总结/问答。', parameters: { type: 'object', properties: {} } },
    run: async () => {
      const t = await activeTab(); await ensureDom(t.id);
      const r = await domCmd(t.id, { cmd: 'extractText', max: 9000 });
      return r?.ok ? r.data : '提取失败：' + (r?.error || '');
    }
  },
  get_selection: {
    schema: { name: 'get_selection', description: '读取用户在当前页面选中的文字（用户说"这段/选中的内容"时用）。', parameters: { type: 'object', properties: {} } },
    run: async () => {
      const t = await activeTab(); await ensureDom(t.id);
      const r = await domCmd(t.id, { cmd: 'selection', max: 6000 });
      return r?.ok ? r.data : '读取选区失败：' + (r?.error || '');
    }
  },
  get_links: {
    schema: { name: 'get_links', description: '提取当前页面上可见的链接（文字 + 网址）。', parameters: { type: 'object', properties: {} } },
    run: async () => {
      const t = await activeTab(); await ensureDom(t.id);
      const r = await domCmd(t.id, { cmd: 'links' });
      return r?.ok ? r.data : '提取链接失败：' + (r?.error || '');
    }
  },
  screenshot: {
    schema: { name: 'screenshot', description: '截取当前可见页面（只能截前台可见的标签；需要看视觉布局/图表时用）。返回图像供你查看。', parameters: { type: 'object', properties: {} } },
    run: async () => {
      const t = await activeTab();
      try {
        const dataUrl = await chrome.tabs.captureVisibleTab(t.windowId, { format: 'jpeg', quality: 60 });
        return { __image: dataUrl, text: '已截图当前页面。' };
      } catch (e) {
        return '截图失败：' + e.message;
      }
    }
  },
  navigate: {
    schema: { name: 'navigate', description: '让当前标签页跳转到一个 URL。', parameters: { type: 'object', properties: { url: { type: 'string' } }, required: ['url'] } },
    run: async ({ url }) => {
      const t = await activeTab();
      await chrome.tabs.update(t.id, { url });
      const tb = await waitForLoad(t.id);
      return '已跳转：' + (tb?.title || url) + ' — ' + (tb?.url || url);
    }
  },
  go_back: {
    schema: { name: 'go_back', description: '当前标签页后退一页。', parameters: { type: 'object', properties: {} } },
    run: async () => { const t = await activeTab(); try { await chrome.tabs.goBack(t.id); } catch (e) { return '无法后退：' + e.message; } await waitForLoad(t.id); const tb = await chrome.tabs.get(t.id); return '已后退：' + (tb?.title || tb?.url || ''); }
  },
  go_forward: {
    schema: { name: 'go_forward', description: '当前标签页前进一页。', parameters: { type: 'object', properties: {} } },
    run: async () => { const t = await activeTab(); try { await chrome.tabs.goForward(t.id); } catch (e) { return '无法前进：' + e.message; } await waitForLoad(t.id); const tb = await chrome.tabs.get(t.id); return '已前进：' + (tb?.title || tb?.url || ''); }
  },
  reload: {
    schema: { name: 'reload', description: '刷新当前标签页。', parameters: { type: 'object', properties: {} } },
    run: async () => { const t = await activeTab(); await chrome.tabs.reload(t.id); await waitForLoad(t.id); return '已刷新当前页面'; }
  },
  search_history: {
    schema: { name: 'search_history', description: '搜索用户的浏览历史。', parameters: { type: 'object', properties: { query: { type: 'string' }, max: { type: 'number', description: '最多返回条数，默认 15' } }, required: ['query'] } },
    run: async ({ query, max }) => {
      const items = await chrome.history.search({ text: query || '', maxResults: Math.min(max || 15, 50), startTime: 0 });
      if (!items.length) return '历史中没找到匹配「' + query + '」的记录';
      return items.map((h) => (h.title ? h.title.slice(0, 70) + ' — ' : '') + h.url).join('\n');
    }
  },
  search_bookmarks: {
    schema: { name: 'search_bookmarks', description: '搜索用户的书签。', parameters: { type: 'object', properties: { query: { type: 'string' } }, required: ['query'] } },
    run: async ({ query }) => {
      const items = (await chrome.bookmarks.search(query || '')).filter((b) => b.url).slice(0, 30);
      if (!items.length) return '书签中没找到匹配「' + query + '」的记录';
      return items.map((b) => (b.title ? b.title.slice(0, 70) + ' — ' : '') + b.url).join('\n');
    }
  },
  list_tabs: {
    schema: { name: 'list_tabs', description: '列出当前窗口所有标签页（带 #id、标题、URL；*为当前活动标签）。', parameters: { type: 'object', properties: {} } },
    run: async () => {
      const tabs = await chrome.tabs.query({ currentWindow: true });
      return tabs.map(tabLine).join('\n');
    }
  },
  open_tab: {
    schema: { name: 'open_tab', description: '新开一个标签页打开 URL。', parameters: { type: 'object', properties: { url: { type: 'string' } }, required: ['url'] } },
    run: async ({ url }) => {
      const t = await chrome.tabs.create({ url, active: true });
      await waitForLoad(t.id);
      return '已新开标签 #' + t.id + '：' + url;
    }
  },
  switch_tab: {
    schema: { name: 'switch_tab', description: '切换到某个标签页（按 #id）。之后的页面操作都作用于它。', parameters: { type: 'object', properties: { tabId: { type: 'number' } }, required: ['tabId'] } },
    run: async ({ tabId }) => {
      const t = await chrome.tabs.update(tabId, { active: true });
      try { await chrome.windows.update(t.windowId, { focused: true }); } catch {}
      return '已切换到 #' + tabId + '：' + (t.title || t.url || '');
    }
  },
  close_tab: {
    schema: { name: 'close_tab', description: '关闭某个标签页（按 #id）。', parameters: { type: 'object', properties: { tabId: { type: 'number' } }, required: ['tabId'] } },
    run: async ({ tabId }) => { await chrome.tabs.remove(tabId); return '已关闭 #' + tabId; }
  },
  group_tabs: {
    schema: {
      name: 'group_tabs',
      description: '把标签页按主题分组（AI 整理标签）。groups 为 [{name, tabIds:[#id...]}]。',
      parameters: { type: 'object', properties: { groups: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, tabIds: { type: 'array', items: { type: 'number' } } }, required: ['name', 'tabIds'] } } }, required: ['groups'] }
    },
    run: async ({ groups }) => {
      let n = 0;
      for (const g of groups || []) {
        if (!g.tabIds?.length) continue;
        const gid = await chrome.tabs.group({ tabIds: g.tabIds });
        try { await chrome.tabGroups.update(gid, { title: g.name }); } catch {}
        n++;
      }
      return '已整理为 ' + n + ' 个分组';
    }
  },
  computer: {
    schema: {
      name: 'computer',
      description: '坐标级输入兜底：当 uid 方式够不着时用（canvas、拖拽、滑块、悬浮菜单等）。坐标是 screenshot 像素空间（自动按 devicePixelRatio 换算），需先 screenshot 看清位置。',
      parameters: {
        type: 'object',
        properties: {
          action: { type: 'string', enum: ['left_click', 'right_click', 'double_click', 'hover', 'drag', 'scroll', 'type', 'key'], description: '动作类型' },
          x: { type: 'number', description: '目标 X（screenshot 像素）' },
          y: { type: 'number', description: '目标 Y（screenshot 像素）' },
          x2: { type: 'number', description: 'drag 终点 X' },
          y2: { type: 'number', description: 'drag 终点 Y' },
          dir: { type: 'string', enum: ['up', 'down', 'left', 'right'], description: 'scroll 方向' },
          text: { type: 'string', description: 'type 要输入的文字' },
          key: { type: 'string', description: 'key 要按的键，如 Enter' }
        },
        required: ['action']
      }
    },
    run: async ({ action, x, y, x2, y2, dir, text, key }) => {
      const t = await activeTab(); await ensureDom(t.id);
      const r = await domCmd(t.id, { cmd: 'mouse', action, x, y, x2, y2, dir, text, key });
      return r?.ok ? r.data : '操作失败：' + (r?.error || '');
    }
  },
  get_editor_value: {
    schema: { name: 'get_editor_value', description: '读取代码编辑器（Monaco / CodeMirror）或 textarea 的完整内容（不被虚拟滚动截断）。填写前用它拿全文，避免丢数据。', parameters: { type: 'object', properties: {} } },
    run: async () => {
      const t = await activeTab();
      try {
        const res = await chrome.scripting.executeScript({ target: { tabId: t.id }, world: 'MAIN', func: __zijilaiReadEditor });
        const val = res && res[0] && res[0].result;
        return (val && String(val)) || '(未找到编辑器内容)';
      } catch (e) {
        return '读取编辑器失败：' + (e?.message || e);
      }
    }
  },
  upload_file_to_input: {
    schema: { name: 'upload_file_to_input', description: '把本地文件上传到页面的 <input type=file>（经 chrome.debugger 的 DOM.setFileInputFiles）。filePath 为绝对路径；多个 file input 时用 inputIndex 选第几个(0起)。会短暂出现"已开始调试"提示。', parameters: { type: 'object', properties: { filePath: { type: 'string', description: '本地文件绝对路径' }, inputIndex: { type: 'number', description: '第几个 file input，默认 0' } }, required: ['filePath'] } },
    run: async ({ filePath, inputIndex }) => {
      const t = await activeTab(); const tabId = t.id;
      if (!filePath) return '需要 filePath（绝对路径）';
      try { await chrome.debugger.attach({ tabId }, '1.3'); }
      catch (e) { return '附加调试器失败：' + (e?.message || e); }
      try {
        await sendDbg(tabId, 'DOM.enable');
        const doc = await sendDbg(tabId, 'DOM.getDocument', { depth: -1 });
        const q = await sendDbg(tabId, 'DOM.querySelectorAll', { nodeId: doc.root.nodeId, selector: 'input[type=file]' });
        const ids = (q && q.nodeIds) || [];
        if (!ids.length) return '页面没有 <input type=file>';
        const nodeId = ids[Math.min(inputIndex || 0, ids.length - 1)];
        await sendDbg(tabId, 'DOM.setFileInputFiles', { nodeId, files: [filePath] });
        return '已上传文件到 input #' + (inputIndex || 0) + '：' + filePath + '（共找到 ' + ids.length + ' 个 file input）';
      } catch (e) {
        return '上传失败：' + (e?.message || e);
      } finally {
        try { await chrome.debugger.detach({ tabId }); } catch {}
      }
    }
  },
  wait: {
    schema: { name: 'wait', description: '等待若干毫秒（页面加载/动画时用）。', parameters: { type: 'object', properties: { ms: { type: 'number' } }, required: ['ms'] } },
    run: async ({ ms }) => { await sleep(ms); return '已等待 ' + ms + 'ms'; }
  }
};

// Built-in tools that change state / can exfiltrate — gated behind user confirm when MCP is active.
export const SIDE_EFFECT_TOOLS = new Set([
  'navigate', 'open_tab', 'fill', 'press_key', 'click', 'close_tab', 'switch_tab', 'group_tabs',
  'computer', 'upload_file_to_input'
]);

export function toolSchemas() {
  return Object.values(TOOLS).map((t) => ({ type: 'function', function: t.schema }));
}

export async function runTool(name, args) {
  const tool = TOOLS[name];
  if (!tool) return { text: '未知工具：' + name };
  try {
    const res = await tool.run(args || {});
    if (res && typeof res === 'object' && res.__image) return { text: res.text || '已截图', image: res.__image };
    return { text: typeof res === 'string' ? res : JSON.stringify(res) };
  } catch (e) {
    const m = e?.message || String(e);
    if (/Cannot access|chrome:\/\/|extension|Missing host permission|cannot be scripted/i.test(m)) {
      return { text: '无法操作当前页面（可能是 chrome:// 或应用商店等受限页面）：' + m };
    }
    return { text: '工具执行出错：' + m };
  }
}
