// ZIJILAI — dom-agent. Injected into the active tab on demand.
// Maintains a uid->element registry and answers structured commands from the side panel.
(function () {
  if (window.__aipexDomReady) return;
  window.__aipexDomReady = true;

  const reg = new Map(); // uid -> element
  let seq = 0;

  const INTERACTIVE = [
    'a[href]', 'button', 'input:not([type="hidden"])', 'textarea', 'select',
    '[role="button"]', '[role="link"]', '[role="tab"]', '[role="menuitem"]',
    '[role="checkbox"]', '[role="radio"]', '[role="switch"]', '[role="option"]',
    '[contenteditable=""]', '[contenteditable="true"]', 'summary', 'label[for]'
  ].join(',');

  function visible(el) {
    if (!el || !el.getBoundingClientRect) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || cs.opacity === '0') return false;
    return true;
  }

  function clip(s, n) {
    s = (s || '').replace(/\s+/g, ' ').trim();
    return s.length > n ? s.slice(0, n) + '…' : s;
  }

  // Pull meaningful metadata from descendants of a weakly-labelled container:
  // image alt text and <time> datetime/title (e.g. IG post links whose date lives in a child <img alt>/<time>).
  function descMeta(el) {
    let extra = '';
    try {
      if (el.querySelector) {
        const img = el.querySelector('img[alt]');
        if (img && img.alt && img.alt.trim()) extra += img.alt.trim();
        const tm = (el.matches && el.matches('time')) ? el : (el.querySelector && el.querySelector('time'));
        if (tm) {
          const d = tm.getAttribute('datetime') || tm.getAttribute('title') || tm.textContent || '';
          if (d.trim()) extra += (extra ? ' · ' : '') + d.trim();
        }
      }
    } catch {}
    return extra;
  }

  function labelFor(el) {
    const aria = el.getAttribute && el.getAttribute('aria-label');
    let base = '';
    if (aria) base = aria;
    else if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') base = el.placeholder || el.value || el.name || el.type || '';
    else if (el.tagName === 'IMG') base = el.alt || '';
    else base = (el.innerText || el.textContent || '').trim() || el.title || el.getAttribute('name') || el.getAttribute('alt') || '';
    base = (base || '').trim();
    // Enrich short/generic labels with descendant alt/time so dates & image captions surface in the snapshot.
    if (base.length < 25) {
      const meta = descMeta(el);
      if (meta && !base.includes(meta)) base = base ? base + ' | ' + meta : meta;
    }
    return base;
  }

  function roleFor(el) {
    const role = el.getAttribute && el.getAttribute('role');
    const tag = el.tagName.toLowerCase();
    if (tag === 'input') return 'input(' + (el.getAttribute('type') || 'text') + ')';
    if (tag === 'a') return 'link';
    if (role) return role;
    return tag;
  }

  function snapshot() {
    reg.clear();
    seq = 0;
    const seen = new Set();
    const lines = [];
    const nodes = document.querySelectorAll(INTERACTIVE);
    for (const el of nodes) {
      if (lines.length >= 200) break;
      if (seen.has(el) || !visible(el)) continue;
      seen.add(el);
      const uid = 'e' + (++seq);
      reg.set(uid, el);
      const label = clip(labelFor(el), 100);
      const extra = el.tagName === 'INPUT' && el.value ? ' value="' + clip(el.value, 40) + '"' : '';
      lines.push('[' + uid + '] ' + roleFor(el) + (label ? ' "' + label + '"' : '') + extra);
    }
    const headings = [...document.querySelectorAll('h1,h2,h3')]
      .filter(visible).slice(0, 20).map((h) => '  ' + h.tagName + ': ' + clip(h.innerText, 90)).join('\n');
    const bodyText = clip(document.body ? document.body.innerText : '', 2000);
    return [
      'URL: ' + location.href,
      'TITLE: ' + document.title,
      '',
      'INTERACTIVE ELEMENTS (use the uid for click/fill):',
      lines.join('\n') || '  (none found)',
      headings ? '\nHEADINGS:\n' + headings : '',
      '\nPAGE TEXT (truncated):\n' + bodyText
    ].join('\n');
  }

  function setValue(el, value) {
    if (el.isContentEditable) {
      el.focus();
      el.textContent = value;
      el.dispatchEvent(new InputEvent('input', { bubbles: true }));
      return;
    }
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    el.focus();
    if (setter) setter.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function find(query) {
    const q = (query || '').toLowerCase();
    const out = [];
    const nodes = document.querySelectorAll(INTERACTIVE + ',h1,h2,h3,h4,p,span,div[role]');
    for (const el of nodes) {
      if (out.length >= 25) break;
      if (!visible(el)) continue;
      const label = labelFor(el);
      if (label && label.toLowerCase().includes(q)) {
        const uid = 'e' + (++seq);
        reg.set(uid, el);
        out.push('[' + uid + '] ' + roleFor(el) + ' "' + clip(label, 100) + '"');
      }
    }
    return out.length ? out.join('\n') : '(no match for "' + query + '")';
  }

  function escapeRe(s) { return s.replace(/[.+^${}()|\\]/g, '\\$&'); }
  function globToRe(glob) {
    let re = '';
    for (let i = 0; i < glob.length; i++) {
      const c = glob[i];
      if (c === '*') re += '.*';
      else if (c === '?') re += '.';
      else if (c === '[') { let j = i + 1, cls = ''; while (j < glob.length && glob[j] !== ']') { cls += glob[j]; j++; } re += '[' + cls + ']'; i = j; }
      else if (c === '{') { let j = i + 1, al = ''; while (j < glob.length && glob[j] !== '}') { al += glob[j]; j++; } re += '(?:' + al.split(',').map(escapeRe).join('|') + ')'; i = j; }
      else re += escapeRe(c);
    }
    try { return new RegExp(re, 'i'); } catch { return new RegExp(escapeRe(glob), 'i'); }
  }

  // glob/grep over a broad node set; returns matching elements with fresh uids (token-efficient vs full snapshot).
  function searchEls(query) {
    const re = globToRe(query || '');
    const out = [];
    const seen = new Set();
    const nodes = document.querySelectorAll(INTERACTIVE + ',img[alt],time,[aria-label],[role],h1,h2,h3,h4');
    for (const el of nodes) {
      if (out.length >= 40) break;
      if (seen.has(el) || !visible(el)) continue;
      const label = clip(labelFor(el), 120);
      const line = roleFor(el) + (label ? ' "' + label + '"' : '');
      if (re.test(line)) {
        seen.add(el);
        const uid = 'e' + (++seq);
        reg.set(uid, el);
        out.push('[' + uid + '] ' + line);
      }
    }
    return out.length ? out.join('\n') : '(no match for "' + query + '")';
  }

  function links() {
    const seen = new Set();
    const out = [];
    for (const a of document.querySelectorAll('a[href]')) {
      if (out.length >= 120) break;
      if (!visible(a)) continue;
      const href = a.href;
      if (!href || href.startsWith('javascript:') || seen.has(href)) continue;
      seen.add(href);
      const text = clip(a.innerText || a.textContent || a.getAttribute('aria-label') || a.title || '', 80);
      out.push((text ? text + ' — ' : '') + href);
    }
    return out.length ? out.join('\n') : '(本页没有可见链接)';
  }

  // ---- coordinate-level input (fallback for canvas / drag / sliders / hover menus) ----
  function ptEvent(type, x, y, extra) {
    return new PointerEvent(type, { bubbles: true, cancelable: true, composed: true, pointerId: 1, pointerType: 'mouse', isPrimary: true, clientX: x, clientY: y, view: window, ...(extra || {}) });
  }
  function msEvent(type, x, y, extra) {
    return new MouseEvent(type, { bubbles: true, cancelable: true, composed: true, clientX: x, clientY: y, view: window, ...(extra || {}) });
  }
  function atPoint(x, y) { return document.elementFromPoint(x, y) || document.body; }

  function mouseAction(m) {
    const dpr = window.devicePixelRatio || 1;
    // incoming coords are screenshot-pixel space (captureVisibleTab is DPR-scaled) → convert to CSS px
    const x = Math.round((m.x || 0) / dpr), y = Math.round((m.y || 0) / dpr);
    const act = m.action || 'left_click';
    if (act === 'scroll') {
      const dx = (m.dir === 'left' ? -1 : m.dir === 'right' ? 1 : 0) * Math.round(innerWidth * 0.6);
      const dy = (m.dir === 'up' ? -1 : 1) * Math.round(innerHeight * 0.6) * (m.dir === 'left' || m.dir === 'right' ? 0 : 1);
      window.scrollBy({ left: dx, top: dy, behavior: 'smooth' });
      return 'scrolled ' + (m.dir || 'down');
    }
    if (act === 'hover') {
      const el = atPoint(x, y);
      el.dispatchEvent(ptEvent('pointermove', x, y));
      el.dispatchEvent(msEvent('mousemove', x, y));
      el.dispatchEvent(msEvent('mouseover', x, y));
      el.dispatchEvent(msEvent('mouseenter', x, y));
      return 'hover @(' + x + ',' + y + ') → ' + clip(labelFor(el), 40);
    }
    if (act === 'key') {
      const el = document.activeElement || atPoint(x, y);
      const k = m.key || 'Enter';
      el.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true }));
      el.dispatchEvent(new KeyboardEvent('keyup', { key: k, bubbles: true }));
      return '已按 ' + k;
    }
    if (act === 'type') {
      const el = atPoint(x, y);
      try { el.focus(); } catch {}
      const t = m.text || '';
      if (el && 'value' in el) setValue(el, (el.value || '') + t);
      else if (el && el.isContentEditable && document.execCommand) document.execCommand('insertText', false, t);
      return '已输入 "' + clip(t, 40) + '"';
    }
    if (act === 'drag') {
      const x2 = Math.round((m.x2 != null ? m.x2 : m.x || 0) / dpr), y2 = Math.round((m.y2 != null ? m.y2 : m.y || 0) / dpr);
      const a = atPoint(x, y);
      a.dispatchEvent(ptEvent('pointerdown', x, y, { button: 0, buttons: 1 }));
      a.dispatchEvent(msEvent('mousedown', x, y, { button: 0, buttons: 1 }));
      const steps = 6;
      for (let i = 1; i <= steps; i++) {
        const ix = x + (x2 - x) * i / steps, iy = y + (y2 - y) * i / steps;
        const e = atPoint(ix, iy);
        e.dispatchEvent(ptEvent('pointermove', ix, iy, { buttons: 1 }));
        e.dispatchEvent(msEvent('mousemove', ix, iy, { buttons: 1 }));
      }
      const b = atPoint(x2, y2);
      b.dispatchEvent(ptEvent('pointerup', x2, y2, { button: 0, buttons: 0 }));
      b.dispatchEvent(msEvent('mouseup', x2, y2, { button: 0, buttons: 0 }));
      b.dispatchEvent(msEvent('click', x2, y2));
      return 'drag (' + x + ',' + y + ')→(' + x2 + ',' + y2 + ')';
    }
    // click family (left/right/double)
    const el = atPoint(x, y);
    const btn = act === 'right_click' ? 2 : 0;
    el.dispatchEvent(ptEvent('pointermove', x, y));
    el.dispatchEvent(msEvent('mousemove', x, y));
    el.dispatchEvent(ptEvent('pointerdown', x, y, { button: btn, buttons: btn === 2 ? 2 : 1 }));
    el.dispatchEvent(msEvent('mousedown', x, y, { button: btn, buttons: btn === 2 ? 2 : 1 }));
    el.dispatchEvent(ptEvent('pointerup', x, y, { button: btn, buttons: 0 }));
    el.dispatchEvent(msEvent('mouseup', x, y, { button: btn, buttons: 0 }));
    if (act === 'right_click') {
      el.dispatchEvent(msEvent('contextmenu', x, y, { button: 2 }));
      return 'right_click @(' + x + ',' + y + ')';
    }
    el.dispatchEvent(msEvent('click', x, y, { button: 0 }));
    if (act === 'double_click') {
      el.dispatchEvent(msEvent('click', x, y, { button: 0 }));
      el.dispatchEvent(msEvent('dblclick', x, y, { button: 0 }));
      return 'double_click @(' + x + ',' + y + ')';
    }
    return act + ' @(' + x + ',' + y + ') → ' + clip(labelFor(el), 40);
  }

  function handle(msg) {
    const cmd = msg.cmd;
    if (cmd === 'snapshot') return { ok: true, data: snapshot() };
    if (cmd === 'search') return { ok: true, data: searchEls(msg.query) };
    if (cmd === 'mouse') return { ok: true, data: mouseAction(msg) };
    if (cmd === 'info') return { ok: true, data: { url: location.href, title: document.title } };
    if (cmd === 'extractText') return { ok: true, data: clip(document.body ? document.body.innerText : '', msg.max || 8000) };
    if (cmd === 'find') return { ok: true, data: find(msg.query) };
    if (cmd === 'links') return { ok: true, data: links() };
    if (cmd === 'selection') {
      const sel = (window.getSelection && window.getSelection().toString()) || '';
      const t = sel.trim();
      return { ok: true, data: t ? clip(t, msg.max || 6000) : '(用户当前没有选中任何文字)' };
    }
    if (cmd === 'scroll') {
      if (msg.uid) {
        const el = reg.get(msg.uid);
        if (!el) return { ok: false, error: '元素已失效，请重新 read_page' };
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        return { ok: true, data: 'scrolled to ' + msg.uid };
      }
      const dy = (msg.direction === 'up' ? -1 : 1) * Math.round(innerHeight * 0.85);
      scrollBy({ top: dy, behavior: 'smooth' });
      return { ok: true, data: 'scrolled ' + (msg.direction || 'down') };
    }
    if (cmd === 'click') {
      const el = reg.get(msg.uid);
      if (!el) return { ok: false, error: '没有该 uid（' + msg.uid + '），请先 read_page' };
      el.scrollIntoView({ block: 'center' });
      el.click();
      return { ok: true, data: '已点击 ' + msg.uid + '（' + clip(labelFor(el), 40) + '）' };
    }
    if (cmd === 'fill') {
      const el = reg.get(msg.uid);
      if (!el) return { ok: false, error: '没有该 uid（' + msg.uid + '），请先 read_page' };
      try { setValue(el, msg.value ?? ''); } catch (e) { return { ok: false, error: '填写失败: ' + e.message }; }
      return { ok: true, data: '已在 ' + msg.uid + ' 填入：' + clip(String(msg.value), 60) };
    }
    if (cmd === 'key') {
      const el = reg.get(msg.uid) || document.activeElement;
      const k = msg.key || 'Enter';
      if (el) {
        el.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true }));
        el.dispatchEvent(new KeyboardEvent('keyup', { key: k, bubbles: true }));
        if (k === 'Enter' && el.form) try { el.form.requestSubmit ? el.form.requestSubmit() : el.form.submit(); } catch {}
      }
      return { ok: true, data: '已按 ' + k };
    }
    return { ok: false, error: '未知命令 ' + cmd };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.__aipex) return;
    try { sendResponse(handle(msg)); }
    catch (e) { sendResponse({ ok: false, error: e.message || String(e) }); }
    return true;
  });
})();
