// ZIJILAI — bridge client. Lets an external MCP client (Claude Code, via zijilai-mcp-bridge)
// drive this extension. Runs inside the background service worker and reuses runTool() from tools.js.
// Connects OUT to the local bridge's WebSocket hub; receives {type:'call'} requests, executes, replies.

import { runTool } from './tools.js';

const BRIDGE_URL = 'ws://127.0.0.1:2199/extension';
let ws = null;
let retry = 0;
let connecting = false;

function scheduleReconnect() {
  retry = Math.min(retry + 1, 6);
  setTimeout(connect, 500 * retry);
}

function connect() {
  if (connecting) return;
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
  connecting = true;
  let sock;
  try {
    sock = new WebSocket(BRIDGE_URL);
  } catch (e) {
    connecting = false;
    scheduleReconnect();
    return;
  }
  ws = sock;

  sock.onopen = () => {
    connecting = false;
    retry = 0;
    try { sock.send(JSON.stringify({ type: 'hello', version: '0.6.1' })); } catch {}
    console.log('[ZIJILAI bridge] connected to', BRIDGE_URL);
  };

  sock.onmessage = async (ev) => {
    let m;
    try { m = JSON.parse(ev.data); } catch { return; }
    if (m.type === 'ping') {
      try { sock.send(JSON.stringify({ type: 'pong', id: m.id })); } catch {}
      return;
    }
    if (m.type === 'call') {
      let result, ok = true, error = '';
      try {
        result = await runTool(m.tool, m.args || {});   // { text, image? }
      } catch (e) {
        ok = false; error = e?.message || String(e);
      }
      try { sock.send(JSON.stringify({ type: 'result', id: m.id, ok, result, error })); } catch {}
    }
  };

  sock.onclose = () => {
    connecting = false;
    if (ws === sock) ws = null;
    scheduleReconnect();
  };

  sock.onerror = () => {
    try { sock.close(); } catch {}
  };
}

// Public entry — safe to call repeatedly (on SW boot, on alarm wake).
export function startBridge() {
  connect();
}
