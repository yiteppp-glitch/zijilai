// ZIJILAI — dom-agent. Injected into the active tab on demand.
// Maintains a uid->element registry and answers structured commands from the side panel.
(function () {
  if (window.__aipexDomReady) return;
  window.__aipexDomReady = true;

  const reg = new Map(); // uid -> element
  let seq = 0;

  const INTERACTIVE = [
    'a[href]', 'button', 'input:not([type="hidden"])', 'textarea', 'select',
    '[role="button"]', '[role="link"]', '[role="tab"]', '[role="menuitem"]',
    '[role="checkbox"]', '[role="radio"]', '[role="switch"]', '[role="option"]',
    '[contenteditable=""]', '[contenteditable="true"]', 'summary', 'label[for]'
  ].join(',');

  function visible(el) {
    if (!el || !el.getBoundingClientRect) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const cs = getComputedStyle(el);
    if (cs.visibility === 'hidden' || cs.display === 'none' || cs.opacity === '0') return false;
    return true;
  }

  function clip(s, n) {
    s = (s || '').replace(/\s+/g, ' ').trim();
    return s.length > n ? s.slice(0, n) + '…' : s;
  }

  function labelFor(el) {
    const aria = el.getAttribute && el.getAttribute('aria-label');
    if (aria) return aria;
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      return el.placeholder || el.value || el.name || el.getAttribute('aria-label') || el.type || '';
    }
    if (el.tagName === 'IMG') return el.alt || '';
    const t = (el.innerText || el.textContent || '').trim();
    if (t) return t;
    return el.title || el.getAttribute('name') || el.getAttribute('alt') || '';
  }

  function roleFor(el) {
    const role = el.getAttribute && el.getAttribute('role');
    const tag = el.tagName.toLowerCase();
    if (tag === 'input') return 'input(' + (el.getAttribute('type') || 'text') + ')';
    if (tag === 'a') return 'link';
    if (role) return role;
    return tag;
  }

  function snapshot() {
    reg.clear();
    seq = 0;
    const seen = new Set();
    const lines = [];
    const nodes = document.querySelectorAll(INTERACTIVE);
    for (const el of nodes) {
      if (lines.length >= 200) break;
      if (seen.has(el) || !visible(el)) continue;
      seen.add(el);
      const uid = 'e' + (++seq);
      reg.set(uid, el);
      const label = clip(labelFor(el), 100);
      const extra = el.tagName === 'INPUT' && el.value ? ' value="' + clip(el.value, 40) + '"' : '';
      lines.push('[' + uid + '] ' + roleFor(el) + (label ? ' "' + label + '"' : '') + extra);
    }
    const headings = [...document.querySelectorAll('h1,h2,h3')]
      .filter(visible).slice(0, 20).map((h) => '  ' + h.tagName + ': ' + clip(h.innerText, 90)).join('\n');
    const bodyText = clip(document.body ? document.body.innerText : '', 2000);
    return [
      'URL: ' + location.href,
      'TITLE: ' + document.title,
      '',
      'INTERACTIVE ELEMENTS (use the uid for click/fill):',
      lines.join('\n') || '  (none found)',
      headings ? '\nHEADINGS:\n' + headings : '',
      '\nPAGE TEXT (truncated):\n' + bodyText
    ].join('\n');
  }

  function setValue(el, value) {
    if (el.isContentEditable) {
      el.focus();
      el.textContent = value;
      el.dispatchEvent(new InputEvent('input', { bubbles: true }));
      return;
    }
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    el.focus();
    if (setter) setter.call(el, value); else el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function find(query) {
    const q = (query || '').toLowerCase();
    const out = [];
    const nodes = document.querySelectorAll(INTERACTIVE + ',h1,h2,h3,h4,p,span,div[role]');
    for (const el of nodes) {
      if (out.length >= 25) break;
      if (!visible(el)) continue;
      const label = labelFor(el);
      if (label && label.toLowerCase().includes(q)) {
        const uid = 'e' + (++seq);
        reg.set(uid, el);
        out.push('[' + uid + '] ' + roleFor(el) + ' "' + clip(label, 100) + '"');
      }
    }
    return out.length ? out.join('\n') : '(no match for "' + query + '")';
  }

  function links() {
    const seen = new Set();
    const out = [];
    for (const a of document.querySelectorAll('a[href]')) {
      if (out.length >= 120) break;
      if (!visible(a)) continue;
      const href = a.href;
      if (!href || href.startsWith('javascript:') || seen.has(href)) continue;
      seen.add(href);
      const text = clip(a.innerText || a.textContent || a.getAttribute('aria-label') || a.title || '', 80);
      out.push((text ? text + ' — ' : '') + href);
    }
    return out.length ? out.join('\n') : '(本页没有可见链接)';
  }

  function handle(msg) {
    const cmd = msg.cmd;
    if (cmd === 'snapshot') return { ok: true, data: snapshot() };
    if (cmd === 'info') return { ok: true, data: { url: location.href, title: document.title } };
    if (cmd === 'extractText') return { ok: true, data: clip(document.body ? document.body.innerText : '', msg.max || 8000) };
    if (cmd === 'find') return { ok: true, data: find(msg.query) };
    if (cmd === 'links') return { ok: true, data: links() };
    if (cmd === 'selection') {
      const sel = (window.getSelection && window.getSelection().toString()) || '';
      const t = sel.trim();
      return { ok: true, data: t ? clip(t, msg.max || 6000) : '(用户当前没有选中任何文字)' };
    }
    if (cmd === 'scroll') {
      if (msg.uid) {
        const el = reg.get(msg.uid);
        if (!el) return { ok: false, error: '元素已失效，请重新 read_page' };
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        return { ok: true, data: 'scrolled to ' + msg.uid };
      }
      const dy = (msg.direction === 'up' ? -1 : 1) * Math.round(innerHeight * 0.85);
      scrollBy({ top: dy, behavior: 'smooth' });
      return { ok: true, data: 'scrolled ' + (msg.direction || 'down') };
    }
    if (cmd === 'click') {
      const el = reg.get(msg.uid);
      if (!el) return { ok: false, error: '没有该 uid（' + msg.uid + '），请先 read_page' };
      el.scrollIntoView({ block: 'center' });
      el.click();
      return { ok: true, data: '已点击 ' + msg.uid + '（' + clip(labelFor(el), 40) + '）' };
    }
    if (cmd === 'fill') {
      const el = reg.get(msg.uid);
      if (!el) return { ok: false, error: '没有该 uid（' + msg.uid + '），请先 read_page' };
      try { setValue(el, msg.value ?? ''); } catch (e) { return { ok: false, error: '填写失败: ' + e.message }; }
      return { ok: true, data: '已在 ' + msg.uid + ' 填入：' + clip(String(msg.value), 60) };
    }
    if (cmd === 'key') {
      const el = reg.get(msg.uid) || document.activeElement;
      const k = msg.key || 'Enter';
      if (el) {
        el.dispatchEvent(new KeyboardEvent('keydown', { key: k, bubbles: true }));
        el.dispatchEvent(new KeyboardEvent('keyup', { key: k, bubbles: true }));
        if (k === 'Enter' && el.form) try { el.form.requestSubmit ? el.form.requestSubmit() : el.form.submit(); } catch {}
      }
      return { ok: true, data: '已按 ' + k };
    }
    return { ok: false, error: '未知命令 ' + cmd };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (!msg || !msg.__aipex) return;
    try { sendResponse(handle(msg)); }
    catch (e) { sendResponse({ ok: false, error: e.message || String(e) }); }
    return true;
  });
})();
